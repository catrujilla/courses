	TITLE "OpSimple2"
	List P = 16F883
	INCLUDE <P16F883.INC>
	
; AQUI VA PALABRA DE CONFIGURACION
	
numeroA		EQU		0x21	; Asignacion de nombre numeroA al resgistro 0x21
numeroB		EQU		0x22	; Asignacion de nombre numeroB al resgistro 0x22
resultado	EQU		0X23	; Asignacion de nombre resultado al resgistro 0x23

;Asignacion de los nombres de los vectores
VECTOR_RESET		EQU	0x00	; Vector de reset, aqui se dirigi el micro cada vez que inicia
VECTOR_INTERRUPCION	EQU	0x04	; Vector de interrupcion, aqui se dirigi el micro cada vez que existe una interrupcion

; Inicio del codigo
	ORG		VECTOR_RESET		; inicio del programa
	GOTO	MAIN
	ORG		VECTOR_INTERRUPCION	;Que debe hacer el micro cuando hay una interrupcion
	GOTO	INTERRUPCION

; -- Manejo de las interrupciones, esto es tema de unas clases mas adelante
INTERRUPCION
	RETFIE		; No se hace nada, solo se retorna y se activan las interrupciones globales
; -- Fin del manejo de las interrupciones

; ** Aqui comienza el codigo principal del programa **
MAIN
	NOP					; Esta intruccion no hace nada...
	MOVLW	B'10101010'	; Cargar este valor en W register (como valor Binario)
	MOVWF	numeroA		; cargar el valor de W en numeroA
	MOVLW	B'00110011'	; Cargar este valor en W register (como valor Binario)
	MOVWF	numeroB		; cargar el valor de W en numeroB
	MOVLW	B'11001100'	; Cargar el valor en W
	ANDWF	numeroA,1	; Que significa este 1?, que sucede si es 0
	MOVLW	B'11010111'	; Cargar el valor en W
	XORLW	H'23'		; Que resultado debe entregar esta operacion?
						; En donde queda almacenada?
	MOVWF	resultado	; cargar el valor del resultado de la suma en W
	MOVF	numeroA,w	; �que significa w?, �en donde lo busco, como lo verifico?
	XORWF	numeroB,f	; �que significa f?, �en donde lo busco, como lo verifico?
	NOP

	END
