	TITLE "OpSimple3"
	List P = 16F883
	INCLUDE <P16F883.INC>
	
; AQUI VA PALABRA DE CONFIGURACION
	
numeroA		EQU		0x21	; Asignacion de nombre numeroA al resgistro 0x21
numeroB		EQU		0x22	; Asignacion de nombre numeroB al resgistro 0x22
resultado	EQU		0X23	; Asignacion de nombre resultado al resgistro 0x23

;Asignacion de los nombres de los vectores
VECTOR_RESET		EQU	0x00	; Vector de reset, aqui se dirigi el micro cada vez que inicia
VECTOR_INTERRUPCION	EQU	0x04	; Vector de interrupcion, aqui se dirigi el micro cada vez que existe una interrupcion

; Inicio del codigo
	ORG		VECTOR_RESET		; inicio del programa
	GOTO	MAIN
	ORG		VECTOR_INTERRUPCION	;Que debe hacer el micro cuando hay una interrupcion
	GOTO	INTERRUPCION

; -- Manejo de las interrupciones, esto es tema de unas clases mas adelante
INTERRUPCION
	RETFIE		; No se hace nada, solo se retorna y se activan las interrupciones globales
; -- Fin del manejo de las interrupciones

; ** Aqui comienza el codigo principal del programa **
MAIN
	NOP					; Esta intruccion no hace nada...
	MOVLW	B'11110000'	; Cargar este valor en W register (como valor Binario)
	MOVWF	numeroA		; cargar el valor de W en numeroA
	MOVLW	B'00001111'	; Cargar este valor en W register (como valor Binario)
	MOVWF	numeroB		; cargar el valor de W en numeroB
	SWAPF	numeroB,0	; �que se hace con esta instruccion?, �que significa el 0?
	MOVWF	resultado	; Cargar el valor que se encuentra en W en el registro resultado
	RRF		numeroA,f	; �que se hace con esta instruccion?
	RRF		numeroA,f	; �Y que logramos al repetirla varias veces?
	COMF	numeroB,f	; �que se hace con esta instruccion?
	RLF		numeroB,f	; �que se hace con esta instruccion?
	RLF		numeroB,w	; �que se hace con esta instruccion?, �que significa w?
	NOP
	END
