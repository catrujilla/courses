	TITLE "OpSimple"
	List P = 16F883
	INCLUDE <P16F883.INC>
	
; AQUI VA PALABRA DE CONFIGURACION
	
numeroA		EQU		0x21	; Asignacion de nombre numeroA al resgistro 0x21
numeroB		EQU		0x22	; Asignacion de nombre numeroB al resgistro 0x22
resultado	EQU		0X23	; Asignacion de nombre resultado al resgistro 0x23

;Asignacion de los nombres de los vectores
VECTOR_RESET		EQU	0x00	; Vector de reset, aqui se dirigi el micro cada vez que inicia
VECTOR_INTERRUPCION	EQU	0x04	; Vector de interrupcion, aqui se dirigi el micro cada vez que existe una interrupcion

; Inicio del codigo
	ORG		VECTOR_RESET		; inicio del programa
	GOTO	MAIN
	ORG		VECTOR_INTERRUPCION	;Que debe hacer el micro cuando hay una interrupcion
	GOTO	INTERRUPCION

; -- Manejo de las interrupciones, esto es tema de unas clases mas adelante
INTERRUPCION
	RETFIE		; No se hace nada, solo se retorna y se activan las interrupciones globales
; -- Fin del manejo de las interrupciones

; ** Aqui comienza el codigo principal del programa **
MAIN
	NOP					; Esta intruccion no hace nada...
	MOVLW	D'79'		; Cargar este valor en W register
	MOVWF	numeroA		; cargar el valor de W en numeroA
	MOVLW	D'103'		; Cargar este valor en W register
	MOVWF	numeroB		; cargar el valor de W en numeroA
	ADDWF	numeroA,w	; Hacer la suma de ambos registros y cargar el valor en W
	MOVWF	resultado	; cargar el valor del resultado de la suma en W
	NOP

	END
