	TITLE "OpSimple4"
	List P = 16F883
	INCLUDE <P16F883.INC>
	
; AQUI VA PALABRA DE CONFIGURACION
	
numeroA		EQU		0x21	; Asignacion de nombre numeroA al resgistro 0x21
numeroB		EQU		0x22	; Asignacion de nombre numeroB al resgistro 0x22
resultado	EQU		0X23	; Asignacion de nombre resultado al resgistro 0x23

;Asignacion de los nombres de los vectores
VECTOR_RESET		EQU	0x00	; Vector de reset, aqui se dirigi el micro cada vez que inicia
VECTOR_INTERRUPCION	EQU	0x04	; Vector de interrupcion, aqui se dirigi el micro cada vez que existe una interrupcion

; Inicio del codigo
	ORG		VECTOR_RESET		; inicio del programa
	GOTO	MAIN
	ORG		VECTOR_INTERRUPCION	;Que debe hacer el micro cuando hay una interrupcion
	GOTO	INTERRUPCION

; -- Manejo de las interrupciones, esto es tema de unas clases mas adelante
INTERRUPCION
	RETFIE		; No se hace nada, solo se retorna y se activan las interrupciones globales
; -- Fin del manejo de las interrupciones

; ** Aqui comienza el codigo principal del programa **
MAIN
	NOP					; Esta intruccion no hace nada...
	MOVLW	B'11111111'	; Cargar este valor en W register (como valor Binario)
	MOVWF	numeroA		; cargar el valor de W en numeroA
	MOVWF	numeroB		; cargar el valor de W en numeroB
	BCF		numeroB,6	; �Que hace esta instruccion?
	MOVF	numeroB,w	; cargar el f en w
	MOVWF	resultado	;cargar el valor de w en el registro resultado
	CLRF	numeroB		; �Que hace esta instruccion?
	DECF	numeroA,f	; �Que hace esta instruccion?
	INCF	numeroB,f	; �Que hace esta instruccion?
	INCF	numeroB,w	; �Que hace esta instruccion?
	NOP
; -- Introduccion a un loop, aplicacion de la instruccion GOTO
LOOP					; Examine con detenimiento este LOOP (ciclo) y concluya al finalizar la clase, que se puede lograr con este tipo de codigo
	DECFSZ	numeroA,f	; �Que hace esta instruccion?
	GOTO	LOOP		; �Que hace esta instruccion?
	NOP					; �Que hace esta instruccion?
	BSF		numeroA,3	; �Que hace esta instruccion?
	INCFSZ	numeroB,f	; �cuantas veces se ejecutara este ciclo completo?
	GOTO	LOOP		; �cuantos ciclos de instruccion se va a demorar este ciclo?
	NOP					; �En cuantos segundos se ejecuta todo el programa?
	END
